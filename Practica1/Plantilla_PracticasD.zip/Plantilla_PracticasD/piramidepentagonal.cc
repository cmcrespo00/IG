#include "auxiliar.h"
#include "malla.h"
#include "piramidepentagonal.h"

PiramidePentagonal::PiramidePentagonal(float h, float r)
{

   // inicializar la tabla de vértices
        
   // inicializar la tabla de caras o triángulos:
   
   // (es importante en cada cara ordenar los vértices en sentido contrario
   //  de las agujas del reloj, cuando esa cara se observa desde el exterior del cubo)



   // inicializar la/s tabla/s de colores
   
}

